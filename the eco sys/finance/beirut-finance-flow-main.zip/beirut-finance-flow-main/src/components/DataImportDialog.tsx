import { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { useAppContext } from "@/context/AppContext";
import {
  parseCsv, mapClients, mapSuppliers, mapProducts,
  SAMPLE_CSV, downloadText, type ImportEntity,
} from "@/lib/csvImport";
import { Upload, Download, FileSpreadsheet, Loader2 } from "lucide-react";

type DupStrategy = "skip" | "update";

interface RunSummary {
  total: number; created: number; updated: number; skipped: number; failed: number;
  errors: Array<{ row: number; reason: string }>;
}

export default function DataImportDialog() {
  const {
    clients, suppliers, products,
    addClient, addSupplier, addProduct,
    updateClient, updateSupplier, updateProduct,
  } = useAppContext();

  const [open, setOpen] = useState(false);
  const [entity, setEntity] = useState<ImportEntity>("clients");
  const [duplicates, setDuplicates] = useState<DupStrategy>("skip");
  const [csvText, setCsvText] = useState<string>("");
  const [fileName, setFileName] = useState<string>("");
  const [running, setRunning] = useState(false);
  const [summary, setSummary] = useState<RunSummary | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const reset = () => {
    setCsvText(""); setFileName(""); setSummary(null);
    if (inputRef.current) inputRef.current.value = "";
  };

  const onFile = async (file: File) => {
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast({ title: "File too large", description: "CSV must be under 5 MB.", variant: "destructive" });
      return;
    }
    const text = await file.text();
    setCsvText(text);
    setFileName(file.name);
    setSummary(null);
  };

  const preview = (() => {
    if (!csvText) return null;
    const { headers, rows } = parseCsv(csvText);
    if (entity === "clients") return { headers, rows, mapped: mapClients(rows, headers) };
    if (entity === "suppliers") return { headers, rows, mapped: mapSuppliers(rows, headers) };
    return { headers, rows, mapped: mapProducts(rows, headers) };
  })();

  const runImport = async () => {
    if (!preview) return;
    setRunning(true);
    const result: RunSummary = {
      total: preview.mapped.valid.length + preview.mapped.invalid.length,
      created: 0, updated: 0, skipped: 0, failed: 0,
      errors: [...preview.mapped.invalid],
    };

    try {
      if (entity === "clients") {
        const byName = new Map(clients.map(c => [c.name.trim().toLowerCase(), c.id]));
        const byEmail = new Map(clients.filter(c => c.email).map(c => [c.email.trim().toLowerCase(), c.id]));
        for (const { row, data } of (preview.mapped as ReturnType<typeof mapClients>).valid) {
          const existingId =
            (data.email && byEmail.get(data.email.toLowerCase())) ||
            byName.get(data.name.toLowerCase());
          if (existingId) {
            if (duplicates === "skip") { result.skipped++; continue; }
            updateClient(existingId, data);
            result.updated++;
          } else {
            const id = await addClient(data);
            if (id) result.created++;
            else { result.failed++; result.errors.push({ row, reason: "Insert failed (limit or backend)" }); }
          }
        }
      } else if (entity === "suppliers") {
        const byName = new Map(suppliers.map(s => [s.name.trim().toLowerCase(), s.id]));
        for (const { row, data } of (preview.mapped as ReturnType<typeof mapSuppliers>).valid) {
          const existingId = byName.get(data.name.toLowerCase());
          if (existingId) {
            if (duplicates === "skip") { result.skipped++; continue; }
            updateSupplier(existingId, data);
            result.updated++;
          } else {
            const id = await addSupplier(data);
            if (id) result.created++;
            else { result.failed++; result.errors.push({ row, reason: "Insert failed" }); }
          }
        }
      } else {
        const bySku = new Map(products.filter(p => p.sku).map(p => [p.sku!.trim().toLowerCase(), p.id]));
        const byName = new Map(products.map(p => [p.name.trim().toLowerCase(), p.id]));
        for (const { row, data } of (preview.mapped as ReturnType<typeof mapProducts>).valid) {
          const existingId =
            (data.sku && bySku.get(data.sku.toLowerCase())) ||
            byName.get(data.name.toLowerCase());
          if (existingId) {
            if (duplicates === "skip") { result.skipped++; continue; }
            updateProduct(existingId, data);
            result.updated++;
          } else {
            const id = await addProduct(data);
            if (id) result.created++;
            else { result.failed++; result.errors.push({ row, reason: "Insert failed (limit or backend)" }); }
          }
        }
      }

      setSummary(result);
      toast({
        title: "Import complete",
        description: `${result.created} created, ${result.updated} updated, ${result.skipped} skipped, ${result.failed} failed.`,
      });
    } finally {
      setRunning(false);
    }
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => { setOpen(o); if (!o) reset(); }}
    >
      <DialogTrigger asChild>
        <Button>
          <Upload className="mr-2 h-4 w-4" />
          Import data
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Import data from CSV</DialogTitle>
          <DialogDescription>
            Upload a CSV file to add clients, suppliers, or products in bulk. Data is scoped to your organization.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>What to import</Label>
              <Select
                value={entity}
                onValueChange={(v) => { setEntity(v as ImportEntity); setSummary(null); }}
              >
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="clients">Clients</SelectItem>
                  <SelectItem value="suppliers">Suppliers</SelectItem>
                  <SelectItem value="products">Products</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>If a row already exists</Label>
              <RadioGroup
                value={duplicates}
                onValueChange={(v) => setDuplicates(v as DupStrategy)}
                className="flex gap-4 pt-2"
              >
                <div className="flex items-center gap-2">
                  <RadioGroupItem value="skip" id="dup-skip" />
                  <Label htmlFor="dup-skip" className="font-normal cursor-pointer">Skip</Label>
                </div>
                <div className="flex items-center gap-2">
                  <RadioGroupItem value="update" id="dup-update" />
                  <Label htmlFor="dup-update" className="font-normal cursor-pointer">Update</Label>
                </div>
              </RadioGroup>
            </div>
          </div>

          <div className="rounded-md border p-3 flex items-center justify-between gap-3">
            <div className="text-sm">
              <div className="font-medium">Need the format?</div>
              <div className="text-muted-foreground">Download a sample CSV with the right column headers.</div>
            </div>
            <Button
              type="button" variant="outline" size="sm"
              onClick={() => downloadText(`${entity}-template.csv`, SAMPLE_CSV[entity])}
            >
              <Download className="mr-2 h-4 w-4" />
              Template
            </Button>
          </div>

          <div className="space-y-2">
            <Label>CSV file</Label>
            <input
              ref={inputRef}
              type="file"
              accept=".csv,text/csv"
              onChange={(e) => { const f = e.target.files?.[0]; if (f) onFile(f); }}
              className="block w-full text-sm file:mr-3 file:rounded-md file:border file:border-input file:bg-background file:px-3 file:py-1.5 file:text-sm file:font-medium hover:file:bg-accent"
            />
            {fileName && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <FileSpreadsheet className="h-4 w-4" /> {fileName}
              </div>
            )}
          </div>

          {preview && (
            <div className="rounded-md border p-3 space-y-2 text-sm">
              <div className="font-medium">Preview</div>
              <div>
                Detected columns:{" "}
                <span className="text-muted-foreground">
                  {preview.headers.join(", ") || "(none)"}
                </span>
              </div>
              <div>
                Valid rows: <span className="font-medium">{preview.mapped.valid.length}</span>
                {" · "}
                Invalid rows: <span className="font-medium">{preview.mapped.invalid.length}</span>
              </div>
              {preview.mapped.invalid.length > 0 && (
                <ul className="text-xs text-destructive list-disc pl-5 max-h-24 overflow-y-auto">
                  {preview.mapped.invalid.slice(0, 10).map((e, i) => (
                    <li key={i}>Row {e.row}: {e.reason}</li>
                  ))}
                </ul>
              )}
            </div>
          )}

          {summary && (
            <div className="rounded-md border p-3 space-y-1 text-sm">
              <div className="font-medium">Result</div>
              <div>Created: {summary.created}</div>
              <div>Updated: {summary.updated}</div>
              <div>Skipped: {summary.skipped}</div>
              <div>Failed: {summary.failed}</div>
              {summary.errors.length > 0 && (
                <details className="text-xs text-destructive">
                  <summary className="cursor-pointer">{summary.errors.length} error(s)</summary>
                  <ul className="list-disc pl-5 max-h-32 overflow-y-auto mt-1">
                    {summary.errors.slice(0, 50).map((e, i) => (
                      <li key={i}>Row {e.row}: {e.reason}</li>
                    ))}
                  </ul>
                </details>
              )}
            </div>
          )}
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => setOpen(false)} disabled={running}>
            Close
          </Button>
          <Button
            onClick={runImport}
            disabled={running || !preview || preview.mapped.valid.length === 0}
          >
            {running && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Import {preview ? `${preview.mapped.valid.length} row(s)` : ""}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
