// Minimal RFC-4180 CSV parser + entity row mappers.
// Pure functions, no I/O. Used by the Settings -> Data Import dialog.

export type CsvRow = Record<string, string>;

/** Parse a CSV string into an array of row objects keyed by header. */
export function parseCsv(input: string): { headers: string[]; rows: CsvRow[] } {
  // Normalize newlines and strip BOM.
  const text = input.replace(/^\uFEFF/, "").replace(/\r\n?/g, "\n");
  if (!text.trim()) return { headers: [], rows: [] };

  const records: string[][] = [];
  let field = "";
  let record: string[] = [];
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (inQuotes) {
      if (ch === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; }
        else { inQuotes = false; }
      } else {
        field += ch;
      }
    } else {
      if (ch === '"') inQuotes = true;
      else if (ch === ",") { record.push(field); field = ""; }
      else if (ch === "\n") { record.push(field); records.push(record); field = ""; record = []; }
      else field += ch;
    }
  }
  // Flush last field/record.
  if (field.length > 0 || record.length > 0) {
    record.push(field);
    records.push(record);
  }

  // Drop fully empty trailing rows.
  const cleaned = records.filter(r => r.some(c => c.trim() !== ""));
  if (cleaned.length === 0) return { headers: [], rows: [] };

  const headers = cleaned[0].map(h => h.trim());
  const rows: CsvRow[] = cleaned.slice(1).map(r => {
    const obj: CsvRow = {};
    headers.forEach((h, idx) => { obj[h] = (r[idx] ?? "").trim(); });
    return obj;
  });
  return { headers, rows };
}

/** Case-insensitive header lookup. */
function pick(row: CsvRow, ...keys: string[]): string {
  const lower: Record<string, string> = {};
  for (const k of Object.keys(row)) lower[k.toLowerCase()] = row[k];
  for (const k of keys) {
    const v = lower[k.toLowerCase()];
    if (v !== undefined && v !== "") return v;
  }
  return "";
}

function toNumber(v: string): number {
  if (!v) return 0;
  const n = Number(String(v).replace(/[, ]/g, ""));
  return Number.isFinite(n) ? n : 0;
}

export type ImportEntity = "clients" | "suppliers" | "products";

export interface MappedClient {
  name: string; address: string; phone: string; email: string; taxId?: string;
}
export interface MappedSupplier {
  name: string; address: string; phone: string; email: string;
}
export interface MappedProduct {
  name: string; description?: string;
  type: "product" | "service" | "composed";
  salePrice: number; rawPrice?: number;
  lowStockAlert?: number; sku?: string; category?: string; serviceCost?: number;
}

export interface MappingIssue { row: number; reason: string; }
export interface MappingResult<T> {
  valid: Array<{ row: number; data: T }>;
  invalid: MappingIssue[];
  headers: string[];
}

export function mapClients(rows: CsvRow[], headers: string[]): MappingResult<MappedClient> {
  const valid: MappingResult<MappedClient>["valid"] = [];
  const invalid: MappingIssue[] = [];
  rows.forEach((r, i) => {
    const name = pick(r, "name", "client", "client name", "full name");
    if (!name) { invalid.push({ row: i + 2, reason: "Missing required 'name'" }); return; }
    valid.push({
      row: i + 2,
      data: {
        name,
        address: pick(r, "address"),
        phone: pick(r, "phone", "telephone", "mobile"),
        email: pick(r, "email", "e-mail"),
        taxId: pick(r, "taxid", "tax id", "tax_id", "vat") || undefined,
      },
    });
  });
  return { valid, invalid, headers };
}

export function mapSuppliers(rows: CsvRow[], headers: string[]): MappingResult<MappedSupplier> {
  const valid: MappingResult<MappedSupplier>["valid"] = [];
  const invalid: MappingIssue[] = [];
  rows.forEach((r, i) => {
    const name = pick(r, "name", "supplier", "supplier name", "vendor");
    if (!name) { invalid.push({ row: i + 2, reason: "Missing required 'name'" }); return; }
    valid.push({
      row: i + 2,
      data: {
        name,
        address: pick(r, "address"),
        phone: pick(r, "phone", "telephone"),
        email: pick(r, "email"),
      },
    });
  });
  return { valid, invalid, headers };
}

export function mapProducts(rows: CsvRow[], headers: string[]): MappingResult<MappedProduct> {
  const valid: MappingResult<MappedProduct>["valid"] = [];
  const invalid: MappingIssue[] = [];
  rows.forEach((r, i) => {
    const name = pick(r, "name", "product", "product name");
    if (!name) { invalid.push({ row: i + 2, reason: "Missing required 'name'" }); return; }
    const typeRaw = pick(r, "type").toLowerCase();
    const type: MappedProduct["type"] =
      typeRaw === "service" ? "service" :
      typeRaw === "composed" ? "composed" : "product";
    const salePriceRaw = pick(r, "saleprice", "sale price", "price", "unit price");
    valid.push({
      row: i + 2,
      data: {
        name,
        description: pick(r, "description") || undefined,
        type,
        salePrice: toNumber(salePriceRaw),
        rawPrice: toNumber(pick(r, "rawprice", "raw price", "cost", "cost price")) || undefined,
        lowStockAlert: toNumber(pick(r, "lowstockalert", "low stock alert", "alert")) || undefined,
        sku: pick(r, "sku") || undefined,
        category: pick(r, "category") || undefined,
        serviceCost: toNumber(pick(r, "servicecost", "service cost")) || undefined,
      },
    });
  });
  return { valid, invalid, headers };
}

/** Sample CSV templates returned as downloadable text. */
export const SAMPLE_CSV: Record<ImportEntity, string> = {
  clients:
    "name,email,phone,address,taxId\n" +
    "Acme Corp,ops@acme.com,+961 1 234 567,Beirut Central,TAX-001\n" +
    "Globex,billing@globex.com,+961 3 987 654,Hamra Street,\n",
  suppliers:
    "name,email,phone,address\n" +
    "Initech,sales@initech.com,+961 1 555 010,Sin El Fil\n" +
    "Hooli,contact@hooli.com,+961 1 555 020,Achrafieh\n",
  products:
    "name,sku,type,salePrice,rawPrice,category,lowStockAlert,description\n" +
    "Espresso Beans 1kg,SKU-001,product,18,11,Coffee,5,Single origin Ethiopia\n" +
    "Consulting Hour,SKU-SVC,service,80,0,Services,,Hourly rate\n",
};

export function downloadText(filename: string, content: string, mime = "text/csv;charset=utf-8") {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
